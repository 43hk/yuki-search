# Yuki Search Edge Plugin

这是 Yuki Search 的 Edge 新标签页插件版本。

## 本地加载

1. 打开 Edge。
2. 进入 `edge://extensions/`。
3. 打开「开发人员模式」。
4. 点击「加载解压缩的扩展」。
5. 选择本目录：`plugin`。

加载后，新建标签页会打开插件内置的 `src/index.html`。

## 注意

- 插件版搜索候选接口使用 `https://search4.yukicloud.top/suggest`。
- 服务器 Nginx 需要允许 `/suggest` 跨域访问，当前配置中的 `Access-Control-Allow-Origin "*"` 可以满足这个需求。
- 壁纸仍然从 `https://uapis.cn` 获取，手机端自动使用 `type=mb`。
